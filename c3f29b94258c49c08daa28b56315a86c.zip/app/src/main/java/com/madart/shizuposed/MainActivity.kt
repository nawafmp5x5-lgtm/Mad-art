
package com.madart.shizuposed
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream
class MainActivity : Activity() {
 private var selectedPos = 0
 private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
  uri?.let {
   val dir = File(filesDir, "cards"); dir.mkdirs()
   val outFile = File(dir, "${selectedPos}.png")
   contentResolver.openInputStream(it)?.use { input ->
    val bmp = BitmapFactory.decodeStream(input)
    FileOutputStream(outFile).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
   }
   updateUI()
  }
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
  layout.addView(TextView(this).apply { text = "MadArt ShizuPosed\nTarget: com.madart.testapp\nlayout_stack_card=0x7f0d0073\nR.id.lCardBackgroundIV\np010o.onEdgeDragStarted\nMediaBrowserCompatCustomActionResultReceiver" })
  for (i in 0..4) {
   val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
   row.addView(Button(this).apply { text = "Set Card $i"; setOnClickListener { selectedPos = i; picker.launch("image/*") } })
   row.addView(ImageView(this).apply { id = 1000+i; layoutParams = LinearLayout.LayoutParams(120,80) })
   layout.addView(row)
  }
  layout.addView(TextView(this).apply { text = "\n1. Install Shizuku Wireless Debugging\n2. Install ShizuPosed 5.9\n3. Install this APK\n4. Enable in ShizuPosed for com.madart.testapp\n5. Launch target FROM ShizuPosed" })
  setContentView(layout); updateUI()
 }
 private fun updateUI() { for (i in 0..4) { val iv = findViewById<ImageView>(1000+i); val f = File(filesDir, "cards/${i}.png"); if (f.exists()) iv.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath)) } }
}
