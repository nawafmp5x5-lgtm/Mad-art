
package com.madart.shizuposed
import android.graphics.BitmapFactory
import android.widget.ImageView
import de.robv.android.xposed.*
import java.io.File
class HookEntry : IXposedHookLoadPackage {
 override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
  if (lpparam.packageName != "com.madart.testapp") return
  try {
   XposedHelpers.findAndHookMethod("p010o.requestKeyboardFocusForVirtualView", lpparam.classLoader, "RemoteActionCompatParcelizer", "p010o.onCreateContextMenu", Int::class.java, "p010o.setPreserveFocusAfterLayout\$MediaDescriptionCompat", object : XC_MethodHook() {
    override fun afterHookedMethod(param: MethodHookParam) {
     try {
      val pos = param.args[1] as Int
      val holder = param.args[2]
      val iv = XposedHelpers.getObjectField(holder, "MediaBrowserCompatCustomActionResultReceiver") as? ImageView ?: return
      val f = File("/data/data/com.madart.shizuposed/files/cards/${pos}.png")
      if (f.exists()) { iv.setImageBitmap(BitmapFactory.decodeFile(f.absolutePath)); iv.scaleType = ImageView.ScaleType.CENTER_CROP }
     } catch (e: Throwable) {}
    }
   })
  } catch (e: Throwable) {}
 }
}
