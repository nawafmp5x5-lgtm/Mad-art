# Phase 1 - Static Analysis

APK: com.mada.madapay

Findings:
- layout_stack_card -> resource ID 0x7f0d0073
- R.id.lCardBackgroundIV
- ViewHolder: p010o.onEdgeDragStarted
  public ImageView MediaBrowserCompatCustomActionResultReceiver;
  this.MediaBrowserCompatCustomActionResultReceiver = (ImageView) view2.findViewById(R.id.lCardBackgroundIV);
- Adapter: p010o.requestKeyboardFocusForVirtualView
- Method: RemoteActionCompatParcelizer(onCreateContextMenu item, int position, setPreserveFocusAfterLayout.MediaDescriptionCompat holder)
  onEdgeDragStarted cardHolder = (onEdgeDragStarted) holder;
  performAction viewBinding = new performAction();
  viewBinding.RemoteActionCompatParcelizer = cardHolder.MediaBrowserCompatCustomActionResultReceiver;

Hook point validated.
