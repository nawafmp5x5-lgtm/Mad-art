# MadArt-ShizuPosed
Built for com.madart.testapp
See docs/research.md
Build via GitHub Actions